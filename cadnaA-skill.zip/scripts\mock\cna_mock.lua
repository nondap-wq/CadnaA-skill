-- cna_mock.lua ------------------------------------------------ offline simulator
-- Implements the subset of the CadnaA-Lua API that the skill's scripts use, so
-- generated scripts can be executed and unit-tested without CadnaA.
-- PHYSICS IS SYNTHETIC (free-field point-source spreading only) -- never use
-- the numbers as acoustic results, only as plumbing/regression fixtures.

local M = {}

local SUPPORTED_TABLES = {
  pt_src = "pt_src", imm = "imm", bld_eval = "bld_eval", Haus = "Haus",
  lin_src = "lin_src", area_src = "area_src", road = "road", wall = "wall",
  barrier = "barrier", ground = "ground", auxiliary_polygon = "auxiliary_polygon",
  lat = "lat", txt = "txt", bitmap = "bitmap", symbol = "symbol",
}

local function now() return os.date("%Y-%m-%dT%H:%M:%S") end

-- ---------------------------------------------------------------- spectra
local Spectrum = {}
Spectrum.__index = function(self, k)
  if type(k) == "number" then return rawget(self, "lin")[k] end
  return Spectrum[k]
end
Spectrum.__len = function(self) return #rawget(self, "lin") end
function Spectrum:getLinear(i) return self.lin[i] or 0 end
function Spectrum:getA(i) return (self.lin[i] or 0) + (self.aw or 0) end

local function spectrum(base)
  local lin = {}
  for i = 1, 9 do lin[i] = base end
  return setmetatable({ lin = lin, aw = 0 }, Spectrum)
end

-- ---------------------------------------------------------------- polygon
local Poly = {}
Poly.__index = Poly
Poly.__len = function(self) return #rawget(self, "v") end

function Poly:all()
  local i = 0
  return function()
    i = i + 1
    local v = rawget(self, "v")[i]
    if v then return v end
  end
end
function Poly:append()
  local v = { X = 0, Y = 0, Z = 0 }
  table.insert(rawget(self, "v"), v)
  return v
end
function Poly:insert_after(prev)
  local v = { X = prev.X, Y = prev.Y, Z = prev.Z }
  for i, p in ipairs(rawget(self, "v")) do
    if p == prev then table.insert(rawget(self, "v"), i + 1, v) return v end
  end
  table.insert(rawget(self, "v"), v)
  return v
end
function Poly:num_vertices() return #rawget(self, "v") end
function Poly:is_closed() return #rawget(self, "v") > 2 end
function Poly:first() return rawget(self, "v")[1] end
function Poly:is_complex() return false end
function Poly:is_convex() return true end
function Poly:area2d()
  local a, v = 0, rawget(self, "v")
  for i = 1, #v do
    local j = (i % #v) + 1
    a = a + v[i].X * v[j].Y - v[j].X * v[i].Y
  end
  return math.abs(a) / 2
end
function Poly:area3d() return self:area2d() end
function Poly:length2d()
  local s, v = 0, rawget(self, "v")
  for i = 1, #v - 1 do
    local dx, dy = v[i + 1].X - v[i].X, v[i + 1].Y - v[i].Y
    s = s + math.sqrt(dx * dx + dy * dy)
  end
  if self:is_closed() then
    local dx, dy = v[1].X - v[#v].X, v[1].Y - v[#v].Y
    s = s + math.sqrt(dx * dx + dy * dy)
  end
  return s
end
function Poly:length3d() return self:length2d() end
function Poly:is_inside(x, y)
  local inside, v = false, rawget(self, "v")
  local j = #v
  for i = 1, #v do
    if ((v[i].Y > y) ~= (v[j].Y > y)) and
       (x < (v[j].X - v[i].X) * (y - v[i].Y) / (v[j].Y - v[i].Y) + v[i].X) then
      inside = not inside
    end
    j = i
  end
  return inside
end
function Poly:simplify_geometry() return true end

-- ---------------------------------------------------------------- objects
local Obj = {}
Obj.__index = function(self, k)
  local attrs = rawget(self, "_a")
  if attrs[k] ~= nil then return attrs[k] end
  local m = Obj[k]
  if m then return m end
  error(("mock: unknown attribute '%s' on object type '%s'"):format(tostring(k), self._t), 2)
end
Obj.__newindex = function(self, k, v)
  rawget(self, "_a")[k] = v
end
Obj.__tostring = function(self)
  return ("<cna-obj %s %s>"):format(self._t, tostring(self._a.ID))
end

function Obj:get(k) return self._a[k] end
function Obj:set(k, v) self._a[k] = v end
function Obj:delete()
  self._deleted = true
  local t = M.cna.tables[self._t]
  for i, o in ipairs(rawget(t, "rows")) do
    if o == self then table.remove(rawget(t, "rows"), i) break end
  end
end
function Obj:clone()
  local o = M.new_obj(self._t)
  for k, v in pairs(self._a) do o._a[k] = v end
  return o
end
function Obj:partlev(...)
  local args = { ... }
  local ok, want_oct = false, false
  for _, a in ipairs(args) do
    if a == "octave" then want_oct = true end
    if a == "active_only" then ok = true end
  end
  if rawget(self, "_lev") == nil then
    M.recalc_receiver(self)
  end
  local lv = rawget(self, "_lev")
  local done = false
  return function()
    if done then return nil end
    done = true
    return self, spectrum(lv), spectrum(lv - 3), spectrum(lv - 6)
  end
end

-- ---------------------------------------------------------------- tables
local Tab = {}
Tab.__index = function(self, k)
  local m = Tab[k]
  if m then return m end
  error(("mock: unknown table method '%s'"):format(tostring(k)), 2)
end
Tab.__len = function(self) return #rawget(self, "rows") end

local function match_id(pattern, id)
  if pattern == nil then return true end
  if id == nil then return false end
  local pat = tostring(pattern)
  if pat:sub(1, 1) == "!" then -- CadnaA ObjectTree style: '!a!b'
    return tostring(id):find((pat:gsub("!", ""))) ~= nil
  end
  return tostring(id):find(pat) ~= nil
end

function Tab:all(opts)
  opts = opts or {}
  local i = 0
  local rows = rawget(self, "rows")
  return function()
    while true do
      i = i + 1
      local o = rows[i]
      if not o then return nil end
      local ok = match_id(opts.id, o._a.ID)
      if ok and opts.active_only and (o._a.MARK or 1) == 0 then ok = false end
      if ok then return o end
    end
  end
end
function Tab:first_by_id(id)
  for _, o in ipairs(rawget(self, "rows")) do
    if match_id(id, o._a.ID) then return o end
  end
  return nil
end
function Tab:append()
  local o = M.new_obj(self._name)
  table.insert(rawget(self, "rows"), o)
  return o
end

-- ---------------------------------------------------------------- cna
local cna = {}
M.cna = cna

function M.new_obj(t)
  local o = setmetatable({ _t = t, _a = { MARK = 1 } }, Obj)
  if t == "imm" or t == "bld_eval" then
    local p = setmetatable({ v = {} }, Poly)
    o._a.poly = nil
    rawset(o, "_poly", p)
  else
    rawset(o, "_poly", setmetatable({ v = {} }, Poly))
  end
  return o
end

-- poly is exposed as an attribute-like field on polygonal objects
local ObjIndex = Obj.__index
Obj.__index = function(self, k)
  if k == "poly" then return rawget(self, "_poly") end
  return ObjIndex(self, k)
end

M.cna._out = {}
M.cna._files = {}
M.cna._project = { name = "mock", area = 0 }

function cna.print(...)
  local t = {}
  for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
  table.insert(cna._out, table.concat(t, "\t"))
end

function cna.version() return "MOCK-lua" end
function cna.project_area() return cna._project.area end
function cna.get_ini_path() return "C:/Users/<user>/AppData/Local/Datakustik/CadnaA/cadnaa.ini" end
function cna.messagebox_timeout() return true end
function cna.quit_at_once() cna._quit = true end
function cna.redraw() return true end
function cna.set_dirty() cna._dirty = true end
function cna.is_dirty() return cna._dirty or false end
cna.dirty = function() cna._dirty = true end

function cna.load_file(p)
  cna._loaded = p
  cna.print("MOCK load_file " .. tostring(p))
  return true
end
function cna.save_file(p)
  cna._files[p] = "project"
  cna._dirty = false
  return true
end
function cna.import_file(p) return cna.load_file(p) end
function cna.export_report_text(p) cna._files[p] = "report" return true end
function cna.export_raster_ascii(p) cna._files[p] = "grid" return true end
function cna.export_raster_shape(p) cna._files[p] = "shape" return true end
function cna.import_file_ascii() return true end
function cna.import_citygml() return true end
function cna.scanfile() return {} end

local function dist2(ax, ay, bx, by)
  local dx, dy = ax - bx, ay - by
  return math.sqrt(dx * dx + dy * dy)
end

function M.recalc_receiver(rec)
  local p = 10 ^ (-200 / 10)
  for _, s in ipairs(rawget(M.cna.tables.pt_src, "rows")) do
    if (s._a.MARK or 1) ~= 0 then
      local r = math.max(dist2(s._a.X or 0, s._a.Y or 0, rec._a.X or 0, rec._a.Y or 0), 1)
      local lw = s._a.LW_LI or s._a.LW or 100
      p = p + 10 ^ ((lw - 20 * math.log(r, 10) - 11) / 10)
    end
  end
  for _, s in ipairs(rawget(M.cna.tables.lin_src, "rows")) do
    if (s._a.MARK or 1) ~= 0 then
      local r = math.max(dist2(s._a.X or 0, s._a.Y or 0, rec._a.X or 0, rec._a.Y or 0), 1)
      local lw = (s._a.LW_LI or 100) - 3
      p = p + 10 ^ ((lw - 20 * math.log(r, 10) - 11) / 10)
    end
  end
  local lv = 10 * math.log(p, 10) + (cna._variant_delta or 0)
  if lv < -99 then lv = -99 end
  rawset(rec, "_lev", lv)
  rec._a.LP1 = lv
  rec._a.LP1_500 = lv
  return lv
end

function cna.calc_all_imm()
  cna._calculated = true
  for o in cna.tables.imm:all() do M.recalc_receiver(o) end
  return true
end

-- ---------------------------------------------------------------- grid
cna.grid = {
  is_present = true,
  sw = { 0, 0 },
  ne = { 100, 100 },
  dx = 5, dy = 5, z = 1.5,
  oversampling = 0,
  display = 1,
  exclude_src = 0, exclude_bld = 0, exclude_bld_3D = 0, use_limits = 0,
}
function cna.grid.is_inside(a, b) return true end
function cna.grid.set_step_size(dx, dy) cna.grid.dx, cna.grid.dy = dx, dy end
function cna.grid.delete_grid() cna.grid.is_present = false end
function cna.grid.lines2contour() return true end
function cna.grid.get_limits() return 20, 20 end

function cna.calc_grid()
  local sw, ne, dx = cna.grid.sw, cna.grid.ne, cna.grid.dx or 5
  local pts = {}
  local y = sw[2]
  local nx, ny = 0, 0
  while y <= ne[2] do
    local x = sw[1]
    while x <= ne[1] do
      local p = 10 ^ (-200 / 10)
      for _, s in ipairs(rawget(cna.tables.pt_src, "rows")) do
        if (s._a.MARK or 1) ~= 0 then
          local r = math.max(dist2(s._a.X or 0, s._a.Y or 0, x, y), 1)
          local lw = s._a.LW_LI or s._a.LW or 100
          p = p + 10 ^ ((lw - 20 * math.log(r, 10) - 11) / 10)
        end
      end
      local lv = 10 * math.log(p, 10)
      if lv < -99 then lv = -99 end
      table.insert(pts, { x = x, y = y, lv = lv })
      nx = nx + 1
      x = x + dx
    end
    ny = ny + 1
    y = y + (cna.grid.dy or dx)
  end
  cna._grid = { points = pts, nx = nx, ny = ny, sw = { sw[1], sw[2] },
                ne = { ne[1], ne[2] }, dx = dx, dy = cna.grid.dy or dx }
  cna._grids_run = (cna._grids_run or 0) + 1
  return true
end
function cna.save_grid(p) cna._files[p] = "grid" return true end
function cna.load_grid(p) cna._loaded_grid = p return true end
function cna.resample_grid() return true end
function cna.limit_calc() return true end
cna.limit = { calc = function() cna._limits = true return true end }

-- ---------------------------------------------------------------- variants
cna.variant = {}
local variant_state = { current = 1, list = { { 1, "V01", "Variant 1" } } }
function cna.variant.all()
  local i = 0
  return function()
    i = i + 1
    local v = variant_state.list[i]
    if v then
      -- iterating activates the variant, matching CadnaA's iterator semantics
      variant_state.current = v[1]
      cna._variant_delta = -(v[1] - 1) * 2.0
      return v[1], v[2], v[3]
    end
  end
end
function cna.variant.is_current_calculated() return cna._calculated or false end
cna.variant.__index = function(_, k)
  if k == "current" then return variant_state.current end
  return rawget(cna.variant, k)
end
cna.variant.__newindex = function(_, k, v)
  if k == "current" then
    local idx = tonumber(v)
    if not idx then
      for i, item in ipairs(variant_state.list) do
        if item[2] == v then idx = i break end
      end
    end
    idx = idx or 1
    variant_state.current = idx
    cna._variant_delta = -(idx - 1) * 2.0   -- synthetic: later variants 2 dB quieter
    return
  end
  rawset(cna.variant, k, v)
end
setmetatable(cna.variant, cna.variant)

-- ---------------------------------------------------------------- eval params
cna.eval_parameter = { current = 1 }
function cna.eval_parameter.all()
  local list = { { 1, "Ld", "dB(A)", 0 }, { 2, "Le", "dB(A)", 0 }, { 3, "Ln", "dB(A)", 0 } }
  local i = 0
  return function()
    i = i + 1
    local v = list[i]
    if v then return v[1], v[2], v[3], v[4] end
  end
end

-- ---------------------------------------------------------------- tables API
local tabs = {}
setmetatable(tabs, {
  __index = function(self, k)
    local rows = rawget(self, "__" .. k)
    if not rows then
      rows = {}
      rawset(self, "__" .. k, rows)
      rawset(self, k, setmetatable({ rows = rows, _name = k }, Tab))
    end
    return rawget(self, k)
  end,
})
cna.tables = tabs

-- ---------------------------------------------------------------- grid arith
cna.grid_arith = {}
function cna.grid_arith.new()
  return {
    R1 = nil, R2 = nil, R3 = nil, R4 = nil, R5 = nil, R6 = nil,
    intersect = false, expr1 = nil,
    execute = function(self2) cna._arith = true return true end,
  }
end

-- ---------------------------------------------------------------- seed / run
function M.seed(spec)
  cna._project.area = spec.area or 0
  cna._project.name = spec.name or "mock"
  if spec.grid then
    cna.grid.sw = { spec.grid.x0 or 0, spec.grid.y0 or 0 }
    cna.grid.ne = { (spec.grid.x0 or 0) + (spec.grid.nx or 10) * (spec.grid.dx or 5),
                    (spec.grid.y0 or 0) + (spec.grid.ny or 10) * (spec.grid.dy or 5) }
    cna.grid.dx = spec.grid.dx or 5
    cna.grid.dy = spec.grid.dy or cna.grid.dx or 5
  end
  for _, s in ipairs(spec.sources or {}) do
    local t = cna.tables[s.table or "pt_src"]
    local o = t:append()
    o._a.ID = s.id or ("S" .. #rawget(t, "rows"))
    o._a.X, o._a.Y, o._a.Z = s.x or 0, s.y or 0, s.z or 1
    o._a.LW_LI = s.lw or 100
    o._a.MARK = 1
  end
  for _, r in ipairs(spec.receivers or {}) do
    local o = cna.tables.imm:append()
    o._a.ID = r.id or ("R" .. #rawget(cna.tables.imm, "rows"))
    o._a.X, o._a.Y, o._a.Z = r.x or 0, r.y or 0, r.z or 4
    o._a.MARK = 1
  end
  if spec.variants then
    variant_state.list = {}
    for i, v in ipairs(spec.variants) do
      variant_state.list[i] = { i, v.short or ("V0" .. i), v.long or ("Variant " .. i) }
    end
  end
end

cna_MOCK = M
return M
