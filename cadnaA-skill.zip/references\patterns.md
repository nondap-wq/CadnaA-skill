# 常见任务写法

每个片段都能直接放进 `runs/xxx.lua`，用 `cna.py lint` + `mock-run` 验证后再真跑。

## 1. 导出所有受音者电平（最常用）

```lua
assert(cna, "must run inside CadnaA-Lua")
cna.messagebox_timeout(2)
cna.calc_all_imm()
cna.print("ID\tLP1\tX\tY")
for imm in cna.tables.imm:all() do
  cna.print(string.format("%s\t%.2f\t%.1f\t%.1f",
    tostring(imm.ID), imm.LP1 or -99, imm.X or 0, imm.Y or 0))
end
```

真跑时把 `cna.print` 的结果写文件更方便：

```lua
local f = assert(io.open("D:/runs/levels.csv", "w"))
for imm in cna.tables.imm:all() do
  f:write(string.format("%s,%.2f\n", tostring(imm.ID), imm.LP1 or -99))
end
f:close()
```

## 2. 改参数后重算并对比

```lua
local wall = cna.tables.wall:first_by_id("W01")
if not wall then error("wall W01 missing") end
local h0 = wall.H
local out = {}
for _, h in ipairs({ 2, 3, 4, 5 }) do
  wall.H = h
  cna.calc_all_imm()
  table.insert(out, string.format("%d\t%.2f", h, cna.tables.imm:first_by_id("IP01").LP1))
end
wall.H = h0
cna.print(table.concat(out, "\n"))
```

## 3. 遍历活动变体，各算一张网格

```lua
for i, short, long in cna.variant.all() do
  cna.print(string.format("%d\t%s\t%s", i, short, long))
  cna.calc_grid()
  cna.save_grid(string.format("D:/runs/grid_%s.cnr", short))
end
```

注意：`cna.variant.all()` 只给活动变体；切变体不要手动写 `current`，容易踩到编号/活动状态不一致。

## 4. 按 ID 模式批量改属性

```lua
-- ObjectTree/正则风格：只处理 ID 形如 A* 的对象
for o in cna.tables.pt_src:all{ id = "A*" } do
  o.LW_LI = o.LW_LI + 3
end
-- 只处理活动对象
for o in cna.tables.road:all{ active_only = true } do
  o:set("DTV", 12000)
end
-- 变体属性
o:set("DTV@V2", 8000)
```

## 5. 新建对象（含多边形）

```lua
local q = cna.tables.pt_src:append()
q.ID, q.X, q.Y, q.Z, q.LW_LI = "PQ99", 100, 200, 2, 102

local p = cna.tables.auxiliary_polygon:append()
local poly = p.poly
local v1 = poly:append() v1.X, v1.Y = 0, 0
local v2 = poly:append() v2.X, v2.Y = 30, 0
local v3 = poly:append() v3.X, v3.Y = 30, 20
local v4 = v2 and poly:insert_after(v2) -- 插在 v2 之后
v4.X, v4.Y = 15, -10
cna.print(string.format("area=%.1f len=%.1f closed=%s", poly:area2d(), poly:length2d(), tostring(poly:is_closed())))
```

## 6. 分频段与最大级

```lua
local q, d, e, n
for q, d, e, n in cna.tables.imm:first_by_id("IP01"):partlev("octave", "active_only") do
  for i = 1, 9 do
    cna.print(string.format("%d\t%.1f\t%.1f", i, d:getLinear(i), d:getA(i)))
  end
end
```

## 7. 加载工程 → 计算 → 导出报告

```lua
cna.messagebox_timeout(2)
cna.load_file("D:/projects/site_a.cna")
-- 旧对象引用此时全部失效，必须重新取
local imm = cna.tables.imm:first_by_id("IP01")
cna.calc_all_imm()
cna.export_report_text("D:/runs/report.txt")
cna.save_grid("D:/runs/grid.cnr")
```

## 8. 批量扫描目录

```lua
for _, file in pairs(cna.scandir("D:/projects", "*.cna")) do
  if file:match("%.cna$") then
    cna.load_file(file)
    cna.calc_all_imm()
    cna.print(file)
  end
end
```

## 9. 调试套路

- 脚本不跑：先看 `cna` 是否存在（`assert(cna)`），再看是否在 CadnaA 内执行。
- 结果为空：受音者是否活动（`MARK`）、是否先 `calc_all_imm()`。
- 文件没生成：路径用 `/`，目录必须已存在（Lua `io.open` 不会建目录）。
- 卡住不动：忘了 `cna.messagebox_timeout`，模态框在等点击。
