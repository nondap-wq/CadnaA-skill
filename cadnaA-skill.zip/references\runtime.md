# 运行机制与排障

## 两条通道

| 通道 | 命令 | 依赖 | 用途 |
|---|---|---|---|
| mock | `cna.py mock-run` | Python + lupa（已装在工作区 `.pylibs`） | 验证脚本逻辑、数据流、产物格式；可无 CadnaA |
| real | `cna.py real-run` | 带 Lua 运行时的 CadnaA 构建 + Windows 桌面会话 | 真实声学计算 |

mock 的 `cna` 是纯 Lua 实现（`scripts/mock/cna_mock.lua`），物理是**合成模型**：
点源 `Lp = LW − 20·lg(r) − 11`，线源按 `LW−3` 处理。只保证“接线正确”，不保证声学正确。

## real-run 的执行链

```
cna.py real-run
  ├─ probe：读 exe 版本 + 扫二进制里的 lua_/cnaevent 标记
  ├─ 备份 %LOCALAPPDATA%\Datakustik\CadnaA\cnaevent.lua（若存在）
  ├─ 写入包装脚本：Load(init,name) → loadfile(目标脚本) → pcall → 写 done.txt → cna.quit_at_once()
  ├─ 启动 cna32d.exe <project.cna>
  ├─ 轮询 out/done.txt（默认 600 s）
  └─ finally：还原 cnaevent.lua，终止进程
```

`done.txt` 三种结果：`OK`、`ERROR: <lua 报错>`、`LOAD_ERROR: <语法错>`；
另有 `TIMEOUT` 与 `PROCESS_EXIT_WITHOUT_MARKER`。

### 为什么必须动 C 盘那一个文件

CadnaA 只从 `CADNAA.INI` 所在目录读 `cnaevent.lua`，路径写死在应用里：

```
%LOCALAPPDATA%\Datakustik\CadnaA\cnaevent.lua
```

这是应用约束，不是本技能的配置选择。`real-run` 因此要求显式 `--ini-write`，
并且在 `finally` 里无条件还原原文件。若该目录已有用户自己的 `cnaevent.lua`，
运行期间会被临时替换，结束后恢复 —— 不要在有人正在用 CadnaA 时并发跑。

## 版本判定与授权判定（两道闸门）

`probe` 扫描可执行文件字节，只看**构建里有没有 Lua**：

- `lua_` / `luaL_`（Lua C API 符号）存在 → 内置 Lua
- `cnaevent` / `cnacmd` 存在 → 支持事件/命令文件

`license` 连到运行中的 CadnaA 窗口（class `cadnaa`），读 Extras 菜单的状态位：

| 命令 ID | 菜单项 | 可用含义 |
|---|---|---|
| 4007 | Extras > Execute Scripts | Lua 可执行 |
| 4168 | Extras > Open Lua Command File | 命令文件可用 |
| 4608 | Extras > Lua-Script Presets | 子项常显“此功能需要PRO模块” |

`GRAYED`(0x1)/`DISABLED`(0x2) 都算不可用；三项全灰 → `lua_licensed=false`。

两次实测：

```
4.3.143.4300  markers {lua_:0, cnaevent:0}      → probe: lua=false（构建无 Lua）
2022.0.189.5221 markers {lua_:3, cnaevent:7}    → probe: lua=true
              但 4007/4168/4608 全部 GRAYED       → license: lua_licensed=false（演示授权）
```

**结论：版本与授权是两个独立闸门。** 2022 构建具备 Lua 运行时，但演示授权把三个入口全部
禁用（中文文案明确写“此功能需要PRO模块”）；`cnaevent.lua` 放进 INI 目录后启动工程，
顶层语句与 `Load` 回调都不执行，说明事件子系统整体未启用。拿到 PRO/正式授权后 `real-run`
应可直接使用，但**未在授权环境验证过**。

## 常见故障

| 现象 | 原因 / 处理 |
|---|---|
| `probe` 退出码 3 | 该版本无 Lua，只能走 mock；升级 CadnaA 后再 real-run |
| `refusing ... without --ini-write` | 安全闸门，确认要改应用配置后再加该开关 |
| `TIMEOUT` | 弹窗未处理：脚本里加 `cna.messagebox_timeout(2)`；或工程太大，加 `--timeout` |
| `LOAD_ERROR` | Lua 语法错，先本地 `cna.py lint`，再 `mock-run` 复现 |
| `ERROR: ...` | 运行时错（对象不存在、属性名拼错）；mock 里可复现大半 |
| 退出后工程没保存 | `quit_at_once()` 丢弃未保存改动；脚本内先 `cna.save_file()` |
| 中文/德文路径失败 | 用 `/` 分隔且避免非 ASCII 目录名，或先复制到 `runs/` 下 |

## 与其他自动化方式的关系

- `/batch=1`（PCSP 分块计算）：CadnaA 自带的批处理，用于大场景分块，不执行 Lua。
- `cnacmd.lua` + Modify Objects 的 “LUA Command” 动作：需要人工在对话框里选对象，
  不适合无人值守；仅当需要“人在环”批量处理时使用。
- `lua_presets` 目录 + Extras ▸ Lua-Script Presets：菜单点击触发，同样不适合自动化。
