-- variant_sweep.lua -- recalculate every active variant and report receiver levels
-- Pattern: cna.variant.all() iterator, never touch cna.variant.current by hand

assert(cna, "must run inside CadnaA-Lua")
cna.messagebox_timeout(2)

local rows = {}
for i, short, long in cna.variant.all() do
  cna.print(string.format("variant\t%d\t%s\t%s", i, short, long))
  cna.calc_all_imm()
  for imm in cna.tables.imm:all() do
    rows[#rows + 1] = string.format("%s,%s,%.2f", short, tostring(imm.ID), imm.LP1 or -99)
    cna.print(rows[#rows])
  end
end

cna.print(string.format("variants_done\t%d", #rows))
