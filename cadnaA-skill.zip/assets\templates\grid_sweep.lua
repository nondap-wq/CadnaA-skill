-- grid_sweep.lua -- move one point source along x and save one grid per step
-- Pattern: append object -> loop -> calc_grid -> save_grid (docs Example 2)

assert(cna, "this script must run inside CadnaA-Lua")
assert(cna.grid.is_present, "load a project with a valid grid first")
cna.messagebox_timeout(2)

local OUT = SCRIPT_DIR or ""          -- mock provides SCRIPT_DIR; in CadnaA use an absolute path
local step = 50
local q = cna.tables.pt_src:append()
q.LW_LI = 100
q.Z = 2

for x = 0, 200, step do
  q.X = 100 + x
  q.Y = 100
  cna.calc_grid()
  cna.save_grid(OUT .. string.format("grid_%03d.cnr", x))
  cna.print(string.format("saved x=%d", x))
end
