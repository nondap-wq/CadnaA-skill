-- receiver_levels.lua -- calculate all receivers and dump their levels
-- Pattern: iterate table -> calc -> read attribute -> cna.print
-- Runs in CadnaA (real) and against the skill mock (synthetic physics).

assert(cna, "this script must run inside CadnaA-Lua")
cna.messagebox_timeout(2)          -- keep unattended runs from stalling on dialogs

local ev = cna.eval_parameter
cna.print("CadnaA " .. cna.version())
cna.print("parameter\tcount")

local total = 0
local n, name, unit, typ
for n, name, unit, typ in ev.all() do
  cna.print(string.format("eval_parameter\t%d\t%s\t%s", n, name, unit))
end

cna.calc_all_imm()

for imm in cna.tables.imm:all() do
  total = total + 1
  local lp = imm.LP1
  cna.print(string.format("%s\t%.2f\t%.3f\t%.3f",
    tostring(imm.ID), lp or -99, imm.X or 0, imm.Y or 0))
end

cna.print(string.format("receivers_total\t%d", total))
