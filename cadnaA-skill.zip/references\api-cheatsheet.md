# CadnaA-Lua API 速查

来源：DataKustik 官方在线文档 Lua 章（https://doku.datakustik.com/CadnaA/en/LUA_scripting.html）。
锚点写作 `页:节`，指官方文档的页面编号与章节序号，便于对照原文核对。

## 1. 运行环境

| 事实 | 值 |
|---|---|
| Lua 版本 | 5.4.8（内置，无需外装）`02:0` |
| 额外数学函数 | `math.atan2/cosh/sinh/tanh/pow/frexp/ldexp/log10` `02:0` |
| 全局对象 | `cna`（仅在 CadnaA 内运行脚本时存在）`08:0` |
| 外部库目录 | 安装目录 `/lua_libs`，需 5.4 兼容 `02:0` |
| 自带库 | LuaSQLite3 `require('lsqlite3')`；IUP `package.loadlib('iuplua54.dll','luaopen_iuplua')` `02:0` |

## 2. 项目级命令 `cna.*`（节选全表）

| 函数 | 作用 |
|---|---|
| `cna.print(...)` | 写输出窗口（mock 里是 stdout） |
| `cna.calc_all_imm()` | 重算所有受音者 |
| `cna.calc_grid()` / `load_grid()` / `save_grid(p)` / `resample_grid()` | 网格计算/载入/保存（按扩展名定格式，默认 `.cnr`）/重采样 |
| `cna.load_file(p)` / `save_file(p)` / `import_file(p)` | 工程载入/保存/导入 |
| `cna.export_report_text(p)` | 报告导出 TXT |
| `cna.export_raster_ascii(p)` / `export_raster_shape(p)` | 当前网格导出 ASCII / SHP |
| `cna.import_file_ascii(p,o,x,y,z,d)` | ASCII 导入；o=对象类型整数，x/y/z=列号，d=分隔符 |
| `cna.import_citygml(p,b,d)` | CityGML 导入；b=1..4 LoD2 设置，d=true/false 重建 DTM |
| `cna.project_area()` / `cna.version()` | 面积 / 版本字符串 |
| `cna.getobj(x)` | 直接取对象：HOBJ 十六进制或整数、`(类型号, 行号)`、`("PQ", 行号)` |
| `cna.hobj(obj)` | 取对象 HOBJ 整数 |
| `cna.polygons_are_intersecting(a,b)` | 多边形相交判断 |
| `cna.scandir(path, ext)` | 返回目录（含子目录）文件绝对路径表；`ext="*.cna"` 过滤 |
| `cna.get_ini_entry(s,k)` / `set_ini_entry(s,k,v)` / `get_ini_path()` | CADNAA.INI 读写 |
| `cna.set_scale(d)` / `redraw()` / `set_weighting(x)` / `get_weighting()` | 视图与选项 |
| `cna.messagebox_timeout(sec)` | 对话框自动关闭秒数（无人值守必设） |
| `cna.activate_protocol(bool)` / `protfile()` | 计算协议开关 / 文件名 |
| `cna.is_dirty()` / `cna.dirty()` | 工程是否已修改 / 标记已修改 |
| `cna.quit_at_once()` | 立即退出 CadnaA（未保存改动丢失） |
| `cna.limit.calc()` | 重算限值 |
| `cna.plot_designer_*` | 绘图排版打印 |

（原文：官方文档 `LUA_Referenz-Commands-on-Project-Level.html`）

## 3. 表对象 `cna.tables.<id>`

标识符示例：`pt_src`（点声源）、`lin_src`、`area_src`、`road`、`imm`（受音者）、
`Haus`（建筑）、`bld_eval`（建筑评价）、`wall`、`ground`、`auxiliary_polygon`、`txt`、`symbol`。

| 语法 | 语义 |
|---|---|
| `for o in cna.tables.T:all() do` | 遍历所有行 |
| `for o in cna.tables.T:all{id="!0*!*1"} do` | 按 ID 正则/ObjectTree 模式过滤 |
| `cna.tables.T:all{active_only=true}` | 仅活动对象 |
| `cna.tables.T:first_by_id(id)` | 首个匹配对象 |
| `cna.tables.T:append()` | 新建对象并追加到表尾 |
| `#cna.tables.T` | 行数 |

官方文档 `LUA_Referenz-Table-Object.html`

## 4. 对象 `cnaobj`

| 语法 | 语义 |
|---|---|
| `o.ATTRIBUTE` | 读写属性（属性名见产品手册“Attributes ABC/DEF…”） |
| `o:set("DTV@V2", v)` / `o:get("ATTRIBUTE")` | 按属性名读写，`@V2` 形式访问变体属性 |
| `o.memo_var.NAME` | memo 文本变量读写（赋值即创建） |
| `o.poly` | 多边形数据 |
| `o:delete()` | 删除对象（必须用冒号） |
| `o:clone()` | 复制对象，返回副本或 nil |
| `o:partlev(...)` | 受音者分频段电平迭代器 |
| `o:break_lines(other)` | 调用“打断线”功能 |

官方文档 `LUA_Referenz-CadnaA-Object.html`、`21_...:0`

## 5. 多边形 `poly`

`poly:all()` / `append()` / `insert_after(prev)` / `area2d()` / `area3d()` / `length2d()` /
`length3d()` / `simplify_geometry(se_xy[, se_z])` / `#poly`(=`num_vertices()`) /
`is_closed()` / `first()` / `is_complex()` / `is_convex()` / `is_inside(x,y)`

官方文档 `LUA_Referenz-Polygon-Object.html`；顶点对象 `24_...`

## 6. 变体

- `cna.variant.current` 读/写当前变体（**从 1 起**，可写编号或短名如 `"V01"`）
- `cna.variant.all()` → `i, shortname, longname`，仅活动变体
- `cna.variant.is_current_calculated()` → bool

官方文档 `LUA_CadnaA-Handling-of-Variants-in-CadnaA-Lua.html`

## 7. 评价参数

- `cna.eval_parameter.all()` → `i, name, unit, type`
- `cna.eval_parameter.current` 读/写当前参数

官方文档 `LUA_CadnaA-Addressing-Evaluation-Parameters-in-CadnaA-Lua.html`

## 8. 网格属性

`cna.grid.is_present`（脚本首行 `assert(cna.grid.is_present)`）、`sw`、`ne`、`dx`/`dy`/`z`、
`oversampling`、`display`（1 等值线/2 等值区/3 栅格/4 无）、`display_range*`、
`is_inside(a,b)`、`get_limits()`、`set_step_size(dx,dy)`、`delete_grid([v])`、
`lines2contour()`、`exclude_src`/`exclude_bld`/`exclude_bld_3D`/`use_limits`。

网格算术：

```lua
local c = cna.grid_arith.new()
c.R1 = "D:/grid/raster.cnr"
c.intersect = true
c.expr1 = "r1-r0"
c:execute()
cna.redraw()
```

官方文档 `LUA_Referenz-Grid-and-Grid-Arithmetics.html`

## 9. 分频段电平

```lua
local q, d, e, n
for q, d, e, n in imm:partlev("octave", "active_only") do
  for i = 1, 9 do cna.print(d:getA(i)) end   -- i=1:31.5Hz … 9:8000Hz
end
```

谱对象：`x[i]` 或 `x:getLinear(i)`（线性）、`x:getA(i)`（A 计权）。
参数：`octave`、`active_only`、`lmax`（最大级）。官方文档 `LUA_Referenz-Partial-Level.html`

## 10. 事件与命令文件

`cnaevent.lua`（与 CADNAA.INI 同目录）定义回调，CadnaA 在对应动作前后各调用一次，
`init>0` 表示动作前、`init<=0` 表示动作后：

| 回调 | 参数 |
|---|---|
| `Load` | Filename |
| `LoadTile` | Filename, Rectangle(l,t,r,b), RadMax |
| `Save` | Filename |
| `SaveTile` | Filename |
| `ChangeVariant` | – |
| `CalcGrid` | – |
| `CalcImm` | – |

官方文档 `LUA_CadnaA-LUA-Events.html`；`cnacmd.lua` 供 Modify Objects 的 “LUA Command” 动作调用
官方文档 `LUA_CadnaA-Action-Lua-Command.html`
