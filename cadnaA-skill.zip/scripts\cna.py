#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""CadnaA-Lua skill CLI.

    python scripts/cna.py probe      [--exe <cna64d.exe>]
    python scripts/cna.py license    [--launch]
    python scripts/cna.py lint       <script.lua> [--strict]
    python scripts/cna.py mock-run   <script.lua> --spec <spec.json> --out <dir>
    python scripts/cna.py real-run   <script.lua> --project <p.cna> --out <dir> [--ini-write]
    python scripts/cna.py new        <template> --dest <file.lua>

`real-run` touches exactly one file outside the working directory: the `cnaevent.lua`
that CadnaA insists on reading next to CADNAA.INI -- and only with --ini-write.
Nothing is written to the CadnaA installation directory.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
CANDIDATES = [r"D:\Program Files\CadnaA64 Demo\cna64d.exe",
              r"C:\Program Files\CadnaA64 Demo\cna64d.exe",
              r"D:\Program Files\CadnaA Demo\cna32d.exe",
              r"C:\Program Files\CadnaA Demo\cna32d.exe"]
DEFAULT_EXE = next((p for p in CANDIDATES if os.path.exists(p)), CANDIDATES[0])
MOCK_LUA = os.path.join(HERE, "mock", "cna_mock.lua")
VENDOR_DIRS = [os.path.join(SKILL, ".pylibs"), os.path.join(os.getcwd(), ".pylibs")]

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------- API surface
CNA_FUNCS = {
    "print", "calc_all_imm", "calc_grid", "load_grid", "save_grid", "resample_grid",
    "load_file", "save_file", "import_file", "import_file_ascii", "import_citygml",
    "export_report_text", "export_raster_ascii", "export_raster_shape",
    "project_area", "version", "redraw", "dirty", "is_dirty", "quit_at_once",
    "messagebox_timeout", "get_ini_path", "get_ini_entry", "set_ini_entry",
    "activate_protocol", "protfile", "set_weighting", "get_weighting",
    "set_scale", "scandir", "getobj", "hobj", "polygons_are_intersecting",
    "limit", "tables", "variant", "eval_parameter", "grid", "grid_arith",
    "plot_designer_print_all", "plot_designer_num_pages", "plot_designer_print_page",
}
TABLE_METHODS = {"all", "first_by_id", "append"}
OBJ_METHODS = {"set", "get", "delete", "clone", "partlev", "break_lines"}
POLY_METHODS = {"all", "append", "insert_after", "area2d", "area3d", "length2d",
                "length3d", "simplify_geometry", "num_vertices", "is_closed",
                "first", "is_complex", "is_convex", "is_inside"}
GRID_ARITH = {"new", "execute"}


def log(*a):
    print(*a, file=sys.stderr)


def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)


# ---------------------------------------------------------------- probe
def file_version(path):
    """Read the VS_FIXEDFILEINFO version without spawning anything."""
    try:
        import ctypes
        from ctypes import wintypes

        class VS_FIXEDFILEINFO(ctypes.Structure):
            _fields_ = [("dwSignature", wintypes.DWORD), ("dwStrucVersion", wintypes.DWORD),
                        ("dwFileVersionMS", wintypes.DWORD), ("dwFileVersionLS", wintypes.DWORD),
                        ("dwProductVersionMS", wintypes.DWORD),
                        ("dwProductVersionLS", wintypes.DWORD),
                        ("dwFileFlagsMask", wintypes.DWORD), ("dwFileFlags", wintypes.DWORD),
                        ("dwFileOS", wintypes.DWORD), ("dwFileType", wintypes.DWORD),
                        ("dwFileSubtype", wintypes.DWORD), ("dwFileDateMS", wintypes.DWORD),
                        ("dwFileDateLS", wintypes.DWORD)]

        ver = ctypes.windll.version
        size = ver.GetFileVersionInfoSizeW(path, None)
        if not size:
            return None
        buf = ctypes.create_string_buffer(size)
        if not ver.GetFileVersionInfoW(path, 0, size, buf):
            return None
        ptr = ctypes.c_void_p()
        ln = wintypes.UINT()
        if not ver.VerQueryValueW(buf, "\\", ctypes.byref(ptr), ctypes.byref(ln)):
            return None
        fi = ctypes.cast(ptr, ctypes.POINTER(VS_FIXEDFILEINFO)).contents
        return "%d.%d.%d.%d" % (fi.dwFileVersionMS >> 16, fi.dwFileVersionMS & 0xFFFF,
                                fi.dwFileVersionLS >> 16, fi.dwFileVersionLS & 0xFFFF)
    except Exception:                                          # noqa: BLE001
        return None


def probe(exe=DEFAULT_EXE):
    info = {"exe": exe, "exists": os.path.exists(exe)}
    if not info["exists"]:
        info.update(version=None, lua=False, reason="executable not found")
        return info
    info["version"] = file_version(exe)
    data = open(exe, "rb").read()
    markers = {k: data.count(k) for k in (b"lua_", b"luaL_", b"cnaevent", b"cnacmd", b"lua54")}
    info["markers"] = {k.decode(): v for k, v in markers.items()}
    info["lua"] = markers[b"lua_"] > 0 or markers[b"cnaevent"] > 0
    if not info["lua"]:
        info["reason"] = ("this build carries no Lua runtime (no lua_/cnaevent symbols "
                          "in the executable; CadnaA-Lua needs a build that embeds Lua)")
    return info


def cmd_probe(a):
    info = probe(a.exe)
    print(json.dumps(info, indent=2, ensure_ascii=False))
    return 0 if info["lua"] else 3


# ---------------------------------------------------------------- license gate
LUA_MENU_IDS = {4007: "Extras > Execute Scripts", 4168: "Extras > Open Lua Command File",
                4608: "Extras > Lua-Script Presets (PRO notice)"}


def _menu_states(want_ids):
    """Read menu states of a running CadnaA window (class 'cadnaa')."""
    import ctypes
    import ctypes.wintypes as wt

    u = ctypes.WinDLL("user32", use_last_error=True)
    u.GetMenu.restype = wt.HMENU
    u.GetSubMenu.restype = wt.HMENU
    u.GetMenuStringW.argtypes = [wt.HMENU, ctypes.c_uint, wt.LPWSTR, ctypes.c_int, ctypes.c_uint]
    MF_BYPOSITION = 0x400

    hwnds = []

    @ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
    def cb(h, _lp):
        b = ctypes.create_unicode_buffer(64)
        u.GetClassNameW(h, b, 64)
        if b.value.lower() == "cadnaa" and u.IsWindowVisible(h):
            hwnds.append(h)
        return True

    u.EnumWindows(cb, 0)
    if not hwnds:
        return None, None
    hwnd = hwnds[0]
    found = {}

    def rec(menu, depth=0):
        for i in range(u.GetMenuItemCount(menu)):
            ident = u.GetMenuItemID(menu, i)
            if ident in want_ids:
                st = u.GetMenuState(menu, i, MF_BYPOSITION)
                found[ident] = st
            sub = u.GetSubMenu(menu, i)
            if sub and depth < 4:
                rec(sub, depth + 1)

    rec(u.GetMenu(hwnd))
    return hwnd, found


def cmd_license(a):
    """Check whether the *license* (not just the binary) enables CadnaA-Lua."""
    hwnd, states = _menu_states(LUA_MENU_IDS)
    launched = None
    if hwnd is None:
        if not a.launch:
            die("CadnaA is not running; use --launch to start it for the check", 3)
        launched = subprocess.Popen([a.exe])
        for _ in range(40):
            time.sleep(0.5)
            hwnd, states = _menu_states(LUA_MENU_IDS)
            if hwnd is not None:
                break
        time.sleep(2)
        hwnd, states = _menu_states(LUA_MENU_IDS)
    rows = []
    licensed = False
    for ident, label in LUA_MENU_IDS.items():
        st = (states or {}).get(ident)
        if st is None:
            rows.append({"id": ident, "item": label, "state": None, "enabled": None})
            continue
        enabled = not (st & 0x0001 or st & 0x0002)
        if ident != 4608 and enabled:
            licensed = True
        rows.append({"id": ident, "item": label, "state": hex(st), "enabled": enabled})
    out = {"window": hex(hwnd) if hwnd else None, "lua_licensed": licensed, "menu": rows}
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if launched is not None:
        try:
            launched.terminate()
        except Exception:                                      # noqa: BLE001
            pass
    return 0 if licensed else 4


# ---------------------------------------------------------------- lint
def cmd_lint(a):
    src = open(a.script, encoding="utf-8").read()
    problems, warnings = [], []
    for n, line in enumerate(src.splitlines(), 1):
        code = re.sub(r"--.*$", "", line)
        for m in re.finditer(r"\bcna\.([A-Za-z_]\w*)", code):
            name = m.group(1)
            if name not in CNA_FUNCS and name not in ("variant", "eval_parameter"):
                warnings.append(f"{n}: cna.{name} is not in the documented API surface")
        for m in re.finditer(r"(?<![\w.])([A-Za-z_]\w*)\s*:\s*([A-Za-z_]\w*)\s*\(", code):
            meth = m.group(2)
            if meth in OBJ_METHODS or meth in POLY_METHODS or meth in TABLE_METHODS:
                continue
            if meth in GRID_ARITH:
                continue
            warnings.append(f"{n}: unknown method ':{meth}('")
        if re.search(r"[A-Za-z]:\\", code) or re.search(
                r"\\[\w.\-]+\.(cna|cnr|txt|csv|shp|dat)\b", code, re.I):
            warnings.append(f"{n}: Windows path separator -- use '/' (Lua reads '\\x' as an escape)")
        if "cna.quit_at_once" in code and "messagebox_timeout" not in src:
            warnings.append(f"{n}: quit_at_once without cna.messagebox_timeout -- modal "
                            "dialogs may hang an unattended run")
    # balanced blocks (rough but catches most generation bugs)
    opens = len(re.findall(r"\b(function|if|for|while)\b", re.sub(r"--.*", "", src)))
    ends = len(re.findall(r"\bend\b", re.sub(r"--.*", "", src)))
    if opens != ends:
        problems.append(f"block keywords: {opens} open vs {ends} 'end' -- unbalanced")
    for w in warnings:
        print("WARN " + w)
    for p in problems:
        print("FAIL " + p)
    if not warnings and not problems:
        print("OK   no issues found")
    return 1 if problems or (a.strict and warnings) else 0


# ---------------------------------------------------------------- mock run
def lua_literal(obj, indent=0):
    pad = "  " * indent
    if obj is True:
        return "true"
    if obj is False:
        return "false"
    if obj is None:
        return "nil"
    if isinstance(obj, str):
        return '"%s"' % obj.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    if isinstance(obj, (int, float)):
        return repr(obj)
    if isinstance(obj, dict):
        items = ",\n".join(f"{pad}  [{lua_literal(k)}] = {lua_literal(v, indent + 1)}"
                           for k, v in obj.items())
        return "{\n%s\n%s}" % (items, pad)
    if isinstance(obj, list):
        items = ",\n".join(f"{pad}  {lua_literal(v, indent + 1)}" for v in obj)
        return "{\n%s\n%s}" % (items, pad)
    return "nil"


def cmd_mock_run(a):
    for d in VENDOR_DIRS:
        if os.path.isdir(d) and d not in sys.path:
            sys.path.insert(0, d)
    try:
        from lupa import LuaRuntime
    except ImportError:
        die("lupa is not installed; run:  python -m pip install lupa", 4)

    script = os.path.abspath(a.script)
    if not os.path.exists(script):
        die(f"script not found: {script}")
    spec = {"sources": [], "receivers": []}
    if a.spec:
        spec = json.load(open(a.spec, encoding="utf-8"))
    outdir = os.path.abspath(a.out or os.path.join(os.path.dirname(script), "out"))
    os.makedirs(outdir, exist_ok=True)

    L = LuaRuntime(unpack_returned_tuples=True)
    L.execute(open(MOCK_LUA, encoding="utf-8").read())
    L.execute("M = cna_MOCK; cna = M.cna")
    L.execute(f"M.seed({lua_literal(spec)})")
    L.globals().SCRIPT_DIR = os.path.dirname(script).replace("\\", "/") + "/"

    t0 = time.time()
    try:
        src = open(script, encoding="utf-8-sig", errors="replace").read()
        L.execute(src)
    except Exception as e:                                     # noqa: BLE001
        print("LUA ERROR: %s" % e, file=sys.stderr)
        return 5
    dt = time.time() - t0

    g = L.globals()
    out = []
    try:
        for v in g.cna._out.values():
            out.append(str(v))
    except Exception:                                          # noqa: BLE001
        pass

    # receivers -> levels
    levels = []
    try:
        tab = g.cna.tables.__imm
        for row in tab.values():
            levels.append({"id": str(row._a["ID"]), "x": row._a["X"], "y": row._a["Y"],
                           "LP1": row._a["LP1"]})
    except Exception:                                          # noqa: BLE001
        pass

    files = {}
    try:
        for k, v in g.cna._files.items():
            files[str(k)] = str(v)
    except Exception:                                          # noqa: BLE001
        pass

    grid = None
    try:
        gd = g.cna._grid
        if gd is not None:
            grid = {"nx": gd["nx"], "ny": gd["ny"], "dx": gd["dx"], "dy": gd["dy"],
                    "points": [{"x": p["x"], "y": p["y"], "lv": p["lv"]}
                               for p in gd["points"].values()]}
    except Exception:                                          # noqa: BLE001
        grid = None

    with open(os.path.join(outdir, "stdout.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(out) + ("\n" if out else ""))
    if levels:
        with open(os.path.join(outdir, "levels.csv"), "w", encoding="utf-8") as f:
            f.write("id,x,y,LP1\n")
            for r in levels:
                f.write("%s,%s,%s,%s\n" % (r["id"], r["x"], r["y"],
                                           "" if r["LP1"] is None else "%.2f" % r["LP1"]))
    if grid:
        with open(os.path.join(outdir, "grid.csv"), "w", encoding="utf-8") as f:
            f.write("x,y,level\n")
            for p in grid["points"]:
                f.write("%s,%s,%.2f\n" % (p["x"], p["y"], p["lv"]))
    summary = {"script": script, "spec": a.spec, "seconds": round(dt, 3),
               "stdout_lines": len(out), "receivers": len(levels),
               "grid_points": len(grid["points"]) if grid else 0,
               "artifacts": files, "outdir": outdir}
    with open(os.path.join(outdir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    if a.json:
        print(json.dumps(summary, indent=2, ensure_ascii=False))
    else:
        print("\n".join(out))
        log(f"mock-run ok: {len(out)} lines, {len(levels)} receivers, "
            f"{summary['grid_points']} grid points -> {outdir}")
    return 0


# ---------------------------------------------------------------- real run
def cmd_real_run(a):
    info = probe(a.exe)
    if not info["lua"]:
        die("CadnaA at %s cannot run Lua scripts: %s" % (a.exe, info.get("reason")), 3)
    if not os.path.exists(a.project):
        die(f"project not found: {a.project}")
    script = os.path.abspath(a.script)
    outdir = os.path.abspath(a.out or os.path.join(os.path.dirname(script), "out"))
    os.makedirs(outdir, exist_ok=True)
    ini_dir = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Datakustik", "CadnaA")
    ini = os.path.join(ini_dir, "cadnaa.ini")
    if not os.path.exists(ini):
        die(f"CADNAA.INI not found at {ini}", 3)
    if not a.ini_write:
        die("refusing to write cnaevent.lua outside the workspace without --ini-write\n"
            f"(CadnaA only reads it from {ini_dir})", 3)

    marker = os.path.join(outdir, "done.txt")
    if os.path.exists(marker):
        os.remove(marker)
    event = os.path.join(ini_dir, "cnaevent.lua")
    backup = event + ".skill-bak"
    if os.path.exists(event) and not os.path.exists(backup):
        shutil.copy2(event, backup)
    wrapper = (
        "-- generated by cadnaa-lua skill; restored after the run\n"
        "local SCRIPT = [[%s]]\n"
        "local DONE = [[%s]]\n"
        "local function run()\n"
        "  local f, err = loadfile(SCRIPT)\n"
        "  if not f then local h = io.open(DONE,'a') h:write('LOAD_ERROR: '..tostring(err)) h:close() return end\n"
        "  local ok, e = pcall(f)\n"
        "  local h = io.open(DONE,'a') h:write(ok and 'OK' or ('ERROR: '..tostring(e))) h:close()\n"
        "end\n"
        "function Load(init, name)\n"
        "  if init and init > 0 then return end\n"
        "  run()\n"
        "  if cna and cna.quit_at_once then cna.quit_at_once() end\n"
        "end\n" % (script, marker))
    open(event, "w", encoding="utf-8", newline="\n").write(wrapper)
    try:
        proc = subprocess.Popen([a.exe, os.path.abspath(a.project)],
                                cwd=outdir, close_fds=True)
        deadline = time.time() + a.timeout
        status = None
        while time.time() < deadline:
            if os.path.exists(marker):
                status = open(marker, encoding="utf-8").read().strip()
                break
            if proc.poll() is not None and not os.path.exists(marker):
                status = "PROCESS_EXIT_WITHOUT_MARKER"
                break
            time.sleep(0.5)
        if status is None:
            status = "TIMEOUT"
        try:
            proc.terminate()
        except Exception:                                      # noqa: BLE001
            pass
    finally:
        if os.path.exists(backup):
            shutil.move(backup, event)
        elif os.path.exists(event):
            os.remove(event)
    print(json.dumps({"status": status, "marker": marker, "outdir": outdir}, ensure_ascii=False))
    return 0 if status.startswith("OK") else 6


# ---------------------------------------------------------------- new
def cmd_new(a):
    tpl = os.path.join(SKILL, "assets", "templates", a.template + ".lua")
    if not os.path.exists(tpl):
        die("unknown template '%s'; available: %s" % (
            a.template, ", ".join(sorted(f[:-4] for f in os.listdir(
                os.path.join(SKILL, "assets", "templates"))))), 2)
    dest = os.path.abspath(a.dest)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.copyfile(tpl, dest)
    print(dest)
    return 0


def main():
    ap = argparse.ArgumentParser(prog="cna.py", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("probe"); p.add_argument("--exe", default=DEFAULT_EXE)
    p.set_defaults(fn=cmd_probe)

    p = sub.add_parser("license")
    p.add_argument("--exe", default=DEFAULT_EXE); p.add_argument("--launch", action="store_true")
    p.set_defaults(fn=cmd_license)

    p = sub.add_parser("lint"); p.add_argument("script"); p.add_argument("--strict", action="store_true")
    p.set_defaults(fn=cmd_lint)

    p = sub.add_parser("mock-run")
    p.add_argument("script"); p.add_argument("--spec"); p.add_argument("--out")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_mock_run)

    p = sub.add_parser("real-run")
    p.add_argument("script"); p.add_argument("--project", required=True)
    p.add_argument("--exe", default=DEFAULT_EXE); p.add_argument("--out")
    p.add_argument("--timeout", type=int, default=600)
    p.add_argument("--ini-write", action="store_true")
    p.set_defaults(fn=cmd_real_run)

    p = sub.add_parser("new"); p.add_argument("template"); p.add_argument("--dest", required=True)
    p.set_defaults(fn=cmd_new)

    a = ap.parse_args()
    sys.exit(a.fn(a))


if __name__ == "__main__":
    main()
