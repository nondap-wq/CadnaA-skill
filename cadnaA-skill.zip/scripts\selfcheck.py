#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Self-check for the cadnaa-lua skill: probe -> lint -> mock-run on every template.

    python scripts/selfcheck.py [--keep]

Exit code 0 only if every step passes. Writes under <workspace>/scratch/selfcheck.
"""
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
ROOT = os.path.dirname(os.path.dirname(SKILL))
CNA = os.path.join(HERE, "cna.py")
OUT = os.path.join(ROOT, "scratch", "selfcheck")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

results = []


def run(args, expect=0):
    p = subprocess.run([sys.executable] + args, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("[PASS] " if ok else "[FAIL] ") + name + (("  " + detail) if detail and not ok else ""))


def main():
    keep = "--keep" in sys.argv
    if os.path.isdir(OUT) and not keep:
        shutil.rmtree(OUT)
    os.makedirs(OUT, exist_ok=True)

    code, out = run([CNA, "probe"])
    info = {}
    try:
        info = json.loads(out[out.index("{"):out.rindex("}") + 1])
    except Exception:                                          # noqa: BLE001
        pass
    has_lua = bool(info.get("lua"))
    record("probe", code in (0, 3) and "version" in info,
           f"exit={code}")
    print(f"       CadnaA {info.get('version')} lua={has_lua}")
    if not has_lua:
        print("       -> real_run backend unavailable on this machine (expected, see SKILL.md)")

    spec = os.path.join(SKILL, "examples", "spec_demo.json")
    templates = sorted(f[:-4] for f in os.listdir(os.path.join(SKILL, "assets", "templates"))
                       if f.endswith(".lua"))
    for tpl in templates:
        script = os.path.join(OUT, tpl + ".lua")
        code, out = run([CNA, "new", tpl, "--dest", script])
        record(f"new:{tpl}", code == 0 and os.path.exists(script), out.strip())

        code, out = run([CNA, "lint", script, "--strict"])
        record(f"lint:{tpl}", code == 0, out.strip()[:300])

        outdir = os.path.join(OUT, tpl + "_out")
        code, out = run([CNA, "mock-run", script, "--spec", spec, "--out", outdir, "--json"])
        summary = {}
        try:
            summary = json.loads(out[out.index("{"):out.rindex("}") + 1])
        except Exception:                                      # noqa: BLE001
            pass
        ok = code == 0 and os.path.exists(os.path.join(outdir, "summary.json"))
        record(f"mock-run:{tpl}", ok, out.strip()[-300:])
        if ok:
            print(f"       receivers={summary.get('receivers')} "
                  f"grid_points={summary.get('grid_points')} "
                  f"artifacts={len(summary.get('artifacts') or {})}")

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(failed)}/{len(results)} checks passed")
    if failed:
        print("failed: " + ", ".join(r[0] for r in failed))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
